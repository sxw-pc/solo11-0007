simulated archive readme - no secrets
